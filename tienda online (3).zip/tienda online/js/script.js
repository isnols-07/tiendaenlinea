//esta es mi parte chicassss
document.addEventListener('DOMContentLoaded', () => {
    const saludo = document.querySelector('.hero-content h1');
    const hora = new Date().getHours();
    
    if (hora < 12) saludo.textContent = "¡Buenos días! Bienvenidos";
    else if (hora < 19) saludo.textContent = "¡Buenas tardes! Bienvenidos";
    else saludo.textContent = "¡Buenas noches! Bienvenidos";
}); 
const btnCarrito = document.querySelector('.btn-cart');
btnCarrito.addEventListener('click', () => {
    alert('Producto añadido al carrito con éxito');
});
//aqui termina lo mio  -Paul
//ni idea de lo que hacen la verdad SUERTEEE!!!!!